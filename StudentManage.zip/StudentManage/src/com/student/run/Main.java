package com.student.run;

import com.student.controller.StudentController;

public class Main {
	public static void main(String[] args) {
		StudentController.getController().mainMenu();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

